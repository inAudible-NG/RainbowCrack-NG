rcracki_mt-GUI 0.2b
 * Copyright 2009, 2010 Dani�l Niggebrugge <niggebrugge@fox-it.com>
 * Copyright 2009, 2010, 2011, 2012 James Nobis <frt@quelrod.net>
 * Copyright 2010, 2011, 2012 Paragon <riikard.nordraak@online.de>

rcracki_mt-GUI is a graphical user interface for rcracki_mt, a multithreaded hash cracker using rainbow tables.

*** INSTALLING ***
* Linux *
[ dev builds run autoreconf ]
./configure
make

* Windows *
Run rcracki_mt-gui-0.2b-win32.exe
Currently only 32bit Windows is supported.

Visit http://www.freerainbowtables.com for more information.
